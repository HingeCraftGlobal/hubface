// Relays the video to the open hubface.org tab, then closes the pop-up (yt-nav sets opener=null, so opener postMessage is impossible).
chrome.runtime.onMessage.addListener(function(msg,sender){
 if(!msg||msg.type!=='hf-yt-load'||!sender.tab)return;
 if(!/^https:\/\/www\.youtube\.com\/watch\?v=[\w-]{11}$/.test(msg.url))return;
 chrome.tabs.query({url:['https://hubface.org/*','https://*.hubface.org/*']},function(tabs){
  if(!tabs.length)return; // no dashboard open: leave pop-up alone
  tabs.forEach(function(t){chrome.tabs.sendMessage(t.id,{type:'hf-yt-load',url:msg.url});});
  chrome.windows.update(tabs[0].windowId,{focused:true});
  chrome.tabs.remove(sender.tab.id);});});
