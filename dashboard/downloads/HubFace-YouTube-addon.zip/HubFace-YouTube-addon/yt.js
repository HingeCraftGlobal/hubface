// Active only in the window yt-nav.js opens (window.name 'hfYtPop'); normal YouTube tabs untouched.
(function(){if(window.name!=='hfYtPop')return;
var RX=/^\/(watch|shorts\/[\w-]{11})/;
function vid(u){var m=/[?&]v=([\w-]{11})/.exec(u.search)||/^\/shorts\/([\w-]{11})/.exec(u.pathname);return m&&m[1];}
document.addEventListener('click',function(e){if(e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey)return;
 var a=e.target.closest&&e.target.closest('a[href]');if(!a)return;var u;try{u=new URL(a.href,location.href);}catch(_){return;}
 if(!/(^|\.)youtube\.com$/.test(u.hostname)||!RX.test(u.pathname))return;var id=vid(u);if(!id)return;
 e.preventDefault();e.stopImmediatePropagation();
 chrome.runtime.sendMessage({type:'hf-yt-load',url:'https://www.youtube.com/watch?v='+id});},true);
// YouTube SPA nav that slips past the click (e.g. keyboard): catch the URL change too.
var last='';setInterval(function(){if(location.href===last)return;last=location.href;var id=vid(location);if(id)chrome.runtime.sendMessage({type:'hf-yt-load',url:'https://www.youtube.com/watch?v='+id});},400);
})();
