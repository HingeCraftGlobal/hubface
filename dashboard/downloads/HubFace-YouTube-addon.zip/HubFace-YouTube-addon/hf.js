document.documentElement.dataset.hfYtExt='1';
chrome.runtime.onMessage.addListener(function(msg){if(msg&&msg.type==='hf-yt-load')window.postMessage({type:'hf-yt-load',url:msg.url,src:'hf-yt-ext'},location.origin);});
